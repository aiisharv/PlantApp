//
//  Plant.swift
//  PlantApp
//
//  Created by . . on 10/28/24.
//

import Foundation
import UIKit

class Plant {
    var PlantName:String = ""
    var PlantDescription:String = ""
    var BloomTime:String = ""
    var Sunlight:String = ""
    var Water:String = ""
    var PlantImage = ""
    var Toxic:String = ""
    var PlantType:String = ""
    var PlantWebsite = ""
}
