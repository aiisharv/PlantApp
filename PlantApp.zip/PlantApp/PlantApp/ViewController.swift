//
//  ViewController.swift
//  PlantApp
//
//  Created by Aisha Ahmed on 10/27/24.
//
// This App is developed as an educational project.

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {
    
    
    @IBOutlet weak var imgPlantImage: UIImageView!
    
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var lblSunlight: UILabel!
    
    @IBOutlet weak var lblWater: UILabel!
    
    @IBOutlet weak var txtDescription: UITextView!
    
    @IBOutlet weak var lblPlantType: UILabel!
    
    @IBOutlet weak var lblToxic: UILabel!
    
    @IBOutlet weak var lblBloomTime: UILabel!
    
    @IBOutlet weak var lblDiffColor: UILabel!
    
    @IBOutlet weak var swFav: UISwitch!
    
    
    var PlantObjectArray = [Plant]()
    var randomPlant = Plant()
    var mySoundFile: AVAudioPlayer!
    
    @IBAction func swFavValChanged(_ sender: Any) {
        if(swFav.isOn) {
            UserDefaults.standard.set(lblName.text, forKey: "favorite")
        }
        else{
            UserDefaults.standard.set("", forKey: "favorite")
        }
    }
    @IBAction func btnNext(_ sender: Any) {
        setLabels()
        
    }
    
    @IBAction func btnWebSite(_ sender: Any) {
        let browserApp = UIApplication.shared
        let url = URL(string: randomPlant.PlantWebsite)
        browserApp.open(url!)
    }

    
    
    func setLabels() {
        randomPlant = PlantObjectArray.randomElement()!
        
        lblName.text = randomPlant.PlantName
        txtDescription.text = randomPlant.PlantDescription
        lblWater.text = randomPlant.Water
        lblSunlight.text = randomPlant.Sunlight
        lblBloomTime.text = randomPlant.BloomTime
        lblToxic.text = randomPlant.Toxic
        lblPlantType.text = randomPlant.PlantType
        
        let fav = UserDefaults.standard.string(forKey: "favorite")
        swFav.isOn = (randomPlant.PlantName == fav)
        
        switch (randomPlant.Toxic){
        case "Yes - Animals, Humans":
            lblDiffColor.backgroundColor = UIColor(red:241/255, green:92/255, blue:12/255, alpha: 1)
            break
        case "Yes - Animals, No - Humans":
            lblDiffColor.backgroundColor = UIColor(red:241/255, green:222/255, blue:24/255, alpha: 1)
            break
        case "No":
            lblDiffColor.backgroundColor = UIColor(red:46/255, green:241/255, blue:25/255, alpha: 1)
            break
        default:
            lblDiffColor.backgroundColor = UIColor(red:182/255, green:219/255, blue:255/255, alpha: 1)
        }
        
        
        
        
        //decorating the controls
        txtDescription.layer.cornerRadius = 15
        txtDescription.layer.borderWidth = 1
        txtDescription.layer.borderColor = UIColor.systemPink.cgColor
        imgPlantImage.image = UIImage(named: randomPlant.PlantImage)
        imgPlantImage.layer.cornerRadius = 15
        imgPlantImage.layer.borderWidth = 2
        imgPlantImage.layer.borderColor = UIColor.white.cgColor
        
        
        mySoundFile.play()
    
        
        
    }
    
    //decorate the controls
    
    
    func populatePlantObjects(){
        let p1 = Plant()
        p1.PlantName = "Cherry Blossom (Prunus serrulata)"
        p1.PlantDescription = " Cherry blossom trees, or Prunus serrulata, are known for their beautiful pale pink to white flowers that bloom briefly in early spring. Originating in Japan, they symbolize renewal and the fleeting nature of life. With smooth, reddish-brown bark and a rounded canopy, these trees reach up to 40 feet tall. They thrive in full sunlight and well-drained soil, adding elegance and tranquility to any landscape. "
        p1.BloomTime = "March - April"
        p1.Sunlight = "6+ hours"
        p1.Water = "Twice weekly"
        p1.PlantImage = "cherry-blossom.jpg"
        p1.PlantType = "Perennial"
        p1.Toxic = "Yes - Animals, No - Humans"
        p1.PlantWebsite = "https://en.wikipedia.org/wiki/Cherry_blossom"
        PlantObjectArray.append(p1)
        
        let p2 = Plant()
        p2.PlantName = "Azalea (Rhododendron)"
        p2.PlantDescription = "Azaleas are vibrant flowering shrubs known for their abundant blooms in shades of pink, red, purple, white, and orange. Belonging to the Rhododendron family, they flower in spring, often creating stunning displays that last several weeks. Azaleas have a compact growth habit and glossy, green leaves that provide year-round interest, though some varieties are deciduous and lose their leaves in winter. They thrive in partial shade and well-drained, slightly acidic soil, making them a popular choice for gardens, borders, and landscaping. "
        p2.BloomTime = "April - May"
        p2.Sunlight = "4 - 6 hours"
        p2.Water = "Once weekly"
        p2.PlantImage = "Azalea.jpg"
        p2.PlantType = "Perennial"
        p2.Toxic = "Yes - Animals, Humans"
        p2.PlantWebsite = "https://en.wikipedia.org/wiki/Azalea"
        PlantObjectArray.append(p2)
        
        let p3 = Plant()
        p3.PlantName = "Monstera (Monstera deliciosa) "
        p3.PlantDescription = " Monstera plants, known as Monstera deliciosa, are popular tropical houseplants with large, glossy, heart-shaped leaves featuring natural splits or holes. Native to Central and South America, they’re admired for their striking foliage and thrive in indirect light with moderate watering, adding a bold, lush look to indoor spaces. "
        p3.BloomTime = "Spring - Fall"
        p3.Sunlight = "4-6 hours"
        p3.Water = "Once every 1 - 2 weeks"
        p3.PlantImage = "monstera.jpg"
        p3.PlantType = "Perennial"
        p3.Toxic = "Yes - Animals, Humans"
        p3.PlantWebsite = "https://en.wikipedia.org/wiki/Monstera_deliciosa"
        PlantObjectArray.append(p3)
        
        let p4 = Plant()
        p4.PlantName = "Peony (Paeonia)"
        p4.PlantDescription = "Peonies, scientifically known as Paeonia, are flowering perennials celebrated for their large, fragrant blooms in shades of pink, white, red, and occasionally yellow. Blooming from late spring to early summer, their flowers can be single, semi-double, or fully double, creating a dramatic garden display. Peonies have dark green, glossy foliage that remains attractive after blooming, adding texture to garden beds. They thrive in full sun to partial shade with well-drained, fertile soil. Known for their longevity, peonies can live for decades, often becoming more prolific with age."
        p4.BloomTime = "April - June"
        p4.Sunlight = "6+ hours"
        p4.Water = "Once every 2 weeks"
        p4.PlantImage = "peonies.jpg"
        p4.PlantType = "Perennial"
        p4.Toxic = "Yes - Animals, No - Humans"
        p4.PlantWebsite = "https://en.wikipedia.org/wiki/Peony"
        PlantObjectArray.append(p4)
        
        let p5 = Plant()
        p5.PlantName = "Hydrangea (Hydrangea macrophylla)"
        p5.PlantDescription = "Hydrangeas are beautiful flowering shrubs known for their large, rounded clusters of blooms, which come in colors like blue, pink, purple, and white. Blooming from late spring through summer, hydrangea flowers can change color based on soil pH—acidic soils produce blue blooms, while alkaline soils yield pink hues. Their lush, green foliage complements the vibrant flowers, making hydrangeas a favorite in gardens and landscapes. They thrive in partial shade with well-drained, moist soil, adding a classic elegance and long-lasting color to any outdoor space."
        p5.BloomTime = "Early - Mid Summer "
        p5.Sunlight = "3-6 hours"
        p5.Water = "Twice a week"
        p5.PlantImage = "Hydrangeas.jpg"
        p5.PlantType = "Perennial"
        p5.Toxic = "Yes - Animals, Humans"
        p5.PlantWebsite = "https://en.wikipedia.org/wiki/Hydrangea"
        PlantObjectArray.append(p5)
        
        let p6 = Plant()
        p6.PlantName = "Petunia (Petunia)"
        p6.PlantDescription = "Petunias are popular annual flowers known for their bright, trumpet-shaped blooms in a variety of colors, including pink, purple, white, and red. Blooming from spring through fall, they add vibrant color to gardens, borders, and hanging baskets. Petunias thrive in full sun and well-drained soil, making them a cheerful, low-maintenance choice for continuous seasonal color."
        p6.BloomTime = "Spring - Fall"
        p6.Sunlight = "6+ hours"
        p6.Water = "Once a week"
        p6.PlantImage = "Petunias.jpg"
        p6.PlantType = "Annual"
        p6.Toxic = "No"
        p6.PlantWebsite = "https://en.wikipedia.org/wiki/Petunia"
        PlantObjectArray.append(p5)
        
        
    }
    
    override func motionBegan(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        imgPlantImage.alpha = 0
        lblName.alpha = 0
        txtDescription.alpha = 0
    }
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        UIView.animate(withDuration: 3, animations: {
            self.imgPlantImage.alpha = 1
            self.lblName.alpha = 1
            self.txtDescription.alpha = 1
        })
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        swFav.isOn = false
        let soundURL = URL(fileURLWithPath: Bundle.main.path(forResource:"birds-chirping-241045", ofType:"wav")!)
        mySoundFile = try?AVAudioPlayer(contentsOf: soundURL)
        populatePlantObjects() // initialize the objects
        setLabels() // set initial value on the labels
        
    }


}


